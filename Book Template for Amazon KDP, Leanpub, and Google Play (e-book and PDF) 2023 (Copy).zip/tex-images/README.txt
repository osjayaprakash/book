% Put your TikZ code into this directory, one file for each image, surrounded by \begin{tikzpicture} ... \end{tikzpicture}

The two examples show a graph (latexeffortcomplexity.tex), and a complex picture (leaves-golden-cut.tex).